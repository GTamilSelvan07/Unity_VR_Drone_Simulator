
public interface PowerUpObject
{
   public void performPowerupOnPlayer(PlayerInterface player);
   public bool checkPlayerIsHit(PlayerInterface player);
}
