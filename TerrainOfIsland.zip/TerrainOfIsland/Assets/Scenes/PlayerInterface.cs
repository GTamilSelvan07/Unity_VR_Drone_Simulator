public interface PlayerInterface
{
    public void getMaxSpeed();
    public void setMaxSpeed(float speed);
}
