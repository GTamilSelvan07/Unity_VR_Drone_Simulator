namespace UnityEngine.TestTools
{
    internal class EnumerableTestState : ScriptableObject
    {
        public int Repeat;
        public int Retry;
    }
}